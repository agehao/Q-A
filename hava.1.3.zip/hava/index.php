<?php get_header(); ?>

<div class="container">
  <div class="row">

    <section class="col-lg-10 offset-lg-1" id="firs">

      <?php get_template_part( 'loop' ); ?>

    </section>
  </div>
</div>

<?php get_footer(); ?>
