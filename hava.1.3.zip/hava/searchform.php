<form class="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
	<input class="hava-search" type="search" name="s" placeholder="<?php esc_attr_e('Search', 'hava'); ?>">
	<hr class="undersearch">
</form>
